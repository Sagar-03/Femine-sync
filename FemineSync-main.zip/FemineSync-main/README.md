#FemineSync

It was a project made by me for an college hackathon which is based as solution of "Healthcare" and "No poverty" for women specially.
The project was based to make an safe community for girls, who can get their personalized data and tracking of their health. By taking their data and using chatbots, algorithms, AI to give them required and intresting information.
And now how we target no poverty is by employing women who are financially weak and want employment, can work for mensurating products manufacturing by our help.
